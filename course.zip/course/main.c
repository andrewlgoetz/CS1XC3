/**
 * @file main.c
 * @author Andrew Goetz (goetza3@mcmaster.ca)
 * @brief Main function
 * @version 0.1
 * @date 2022-04-10
 * 
 * @copyright Copyright (c) 2022
 * 
 */


#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

/**
 * @brief Main function that prints randomly generated course and student data using defined libraries time and course (includes student).
 * 
 * First a course MATH101 is defined, with all appropriate fields. Then 20 randomly generated students (each with 8 grades)
 * are enrolled in the course. The course information is printed using print_course(), thus printing every student in the course.
 * The single student best performing student is printed using top_student(), subsequently all students that are passing (average above 50) 
 * are printed using passing(). 0 is returned.
 * 
 * 
 * @return int 
 */

int main()
{
  //random numbers
  srand((unsigned) time(NULL));

  // creates course Math101, type Course
  Course *MATH101 = calloc(1, sizeof(Course));
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

  // enrolls random students to the course
  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  
  //prints course
  print_course(MATH101);

  //finds top student in Math101 and assigns to the variable student, prints student.
  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);

  //prints number of passing students (using passing) and data for each passing student (using print_student).
  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0;
}