
/**
 * @file student.c
 * @author Andrew Goetz (goetza3@mcmaster.ca)
 * @brief Function definitions for type student included in student library.
 * @version 0.1
 * @date 2022-04-08
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

/**
 * @brief Adds a grade to a student's array field of grades
 * 
 * If student does not have any current grades than calloc is used to allocate a static single grade for memory.
 * If the sutdent has existing grades, realloc is used to allocate a additional memory. After memory allocation
 * the new grade is assigned to the last place in the array. Nothing is returned.
 * 
 * @param student 
 * @param grade 
 * @return nothing
 */
void add_grade(Student* student, double grade)
{
  //updates counter for number of grades.
  student->num_grades++;

  //if student has no grades, than calloc allocates a static amount of memory, for the first grade.
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double));
  else 
  {
    // if the student already has grades, realloc increases the amount of allocated memory.
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades);
  }
  
  // last index updated.
  student->grades[student->num_grades - 1] = grade;
}

/**
 * @brief Finds the average grade of a type student.
 * 
 * Provided student->grades is not empty, the function itarates through the grades array and calculates
 * the average value, using student->num_grades for array length. the average is returned as a double.
 * 
 * @param student 
 * @return double 
 */

double average(Student* student)
{
  // if they dont have any grade currently
  if (student->num_grades == 0) return 0;

  // for loop to find the mean using a temporary total variable.
  double total = 0;
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i];
  return total / ((double) student->num_grades);
}

/**
 * @brief Prints all relevant fields and data of type student.
 * 
 * Prints all fields of type student in order: Name (first last), ID, list of grades, and grades average (using average function).
 * Nothing is Returned.
 * 
 * @param student 
 * @return nothing
 */

void print_student(Student* student)
{
  //prints fields for a type Student
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  for (int i = 0; i < student->num_grades; i++) 
    printf("%.2f ", student->grades[i]);
  printf("\n");
  
  //print student average using average()
  printf("Average: %.2f\n\n", average(student));
}

/**
 * @brief generates random value of type student with random name, grades (num_grades passed as argument), ID, etc. 
 * 
 * All randomly generated fields are assigned to the returned value new_student of type student.
 * First and last name are each chosen from an 2D-array of 24 candidates. ID is also randomized
 * using rand(). The number of grades is passed in as argument, but each individual value in the array
 * is random between 25 and 100 (using rand()), values assigned using for loop.
 * 
 * @param grades 
 * @return Student* 
 */

Student* generate_random_student(int grades)
{

  // 2D- array first/ last name candidates.
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
 
  //new student returned value.
  Student *new_student = calloc(1, sizeof(Student));

  // assigns first and last namea
  strcpy(new_student->first_name, first_names[rand() % 24]);
  strcpy(new_student->last_name, last_names[rand() % 24]);

  //generates radnom ID
  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);
  new_student->id[10] = '\0';

  // assigns random grades
  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75)));
  }

  return new_student;
}