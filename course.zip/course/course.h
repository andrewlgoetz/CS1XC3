/**
 * @file course.h
 * @author Andrew Goetz (goetza3@mcmaster.ca)
 * @brief Library of functions for type course.
 * @version 0.1
 * @date 2022-04-10
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include "student.h"
#include <stdbool.h>
/**
 * Course type stores a course with fields name, code, students, and total_students
 * 
 */
typedef struct _course 
{
  char name[100]; /**< The course name (type string) */
  char code[10]; /**< The course code (type string) */
  Student *students; /**< Pointer to custom type Student (for array of enrolled students) */
  int total_students; /**< Counter for total number of students in course (type int) */
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


