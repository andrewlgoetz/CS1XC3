/**
 * @file student.h
 * @author Andrew Goetz (goetza3@mcmaster.ca)
 * @brief Library of functions for type student.
 * @version 0.1
 * @date 2022-04-10
 * 
 * @copyright Copyright (c) 2022
 * 
 */


/**
 * Student type stores an idividual student with fields for first and last name, ID, grades, number of grades
 * 
 */
typedef struct _student 
{ 
  char first_name[50]; /**< The student's first name (string)  */
  char last_name[50]; /**<  The student's last name (string) */
  char id[11]; /**< The student's ID (string)*/
  double *grades; /**< Pointer for array of student's grades (double) */
  int num_grades; /**< Number of grades associated with student (int) */
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
