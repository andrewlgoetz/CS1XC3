/**
 * @file course.c
 * @author Andrew Goetz (goetza3@mcmaster.ca)
 * @brief Function definitions for type course included in course library.
 * @version 0.1
 * @date 2022-04-08
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include "course.h"
#include <stdlib.h>
#include <stdio.h>

/**
 * 
 * @brief Adds a type Student to a type Course. Updates all relevant fields.
 * 
 * "Enrolls" students in to a course by adding the 'student' parameter of type Student
 * to the 'course' parameter's array field of 'students'. The total_students field is updated. 
 * If the array has only the initaliazed value, then the student in question becomes the head, and 
 * only element of the array, using calloc(). If there are other Students in course->students realloc 
 * allocates additional memory for one more student. the student is subsequently placed in the array.
 * Nothing is returned.
 * 
 * @param course 
 * @param student 
 * @return nothing
 */
void enroll_student(Course *course, Student *student)
{ 
  // Increases the counter for number of students in a course
  course->total_students++;
  if (course->total_students == 1) 
  {
    // if there are no students currently in the class than static calloc memory allocated
    course->students = calloc(1, sizeof(Student));
  }
  else 
  {
    // If there are already students enrolled than realloc increases the allocated memory 
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  // last index updated.
  course->students[course->total_students - 1] = *student;
}

/**
 * @brief Prints a course name, code, number of sutdents, and a list of all students.
 * 
 * Print function for custom type Course. Given parameter 'course', a pointer of type Course,
 * the function prints it's name, code, and total_students fields. Subsequently the function
 * iterates through the array of enrolled students and calls print_student to print each one.
 * Nothing is returned.
 * 
 * @param course 
 * @return nothing
 */

void print_course(Course* course)
{
  // course fields printed
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  // print data for each student 'enrolled' in the course
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/**
 * @brief Finds the student enrolled in the given 'course' with the highest 'average'.
 * 
 * Provided there are students enrolled in the course, the function sets temporary values for student average,
 * max average, and a dummy 'student' of type Student*. As the array of students enrolled in the course is iterated through
 * the highest values are found through comparison to the defined temporary variables. The 'student' with the highest average
 * after iteration is returned. In this case "average" refers to a student's grades field and is found using the 'average' function.
 * 
 * @param course 
 * @return Student* 
 */
Student* top_student(Course* course)
{
  // If course is empty (no students)
  if (course->total_students == 0) return NULL;

  // counter and temporary variables for comparison by iterartion
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];

 // iterates through enrolled students, comparison alogrithm to find highest average grade.
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

/**
 * @brief Returns an array of all students in a course that are passing ie. average grade higher than 50.
 * 
 * A first for loop is used to determine the size of the array necessary based on how many students are passing. Memory
 * is then allocated to *passing, which will be the returned value. After memory allocation, a second for-loop
 * assigns students to the passing array if their grades average is 50 or above. The argument *total_passing is updated
 * to reflect the number of students passing the course.
 * 
 * @param course 
 * @param total_passing 
 * @return Student* 
 */
Student *passing(Course* course, int *total_passing)
{
  //counter, and return variable
  int count = 0;
  Student *passing = NULL;
  
  //first for loop finds number of studentrs that are passing (average above 50)
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  //for array of passing students.
  passing = calloc(count, sizeof(Student));

  // second for loop assigns students that are currently passing to the array.
  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }
  // updates argument for number of passing students.
  *total_passing = count;

  return passing;
}